/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F46K20
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB 	          :  MPLAB X 6.00	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set Gate1 aliases
#define Gate1_TRIS                 TRISAbits.TRISA0
#define Gate1_LAT                  LATAbits.LATA0
#define Gate1_PORT                 PORTAbits.RA0
#define Gate1_ANS                  ANSELbits.ANS0
#define Gate1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define Gate1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define Gate1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define Gate1_GetValue()           PORTAbits.RA0
#define Gate1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define Gate1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define Gate1_SetAnalogMode()      do { ANSELbits.ANS0 = 1; } while(0)
#define Gate1_SetDigitalMode()     do { ANSELbits.ANS0 = 0; } while(0)

// get/set Gate2 aliases
#define Gate2_TRIS                 TRISAbits.TRISA1
#define Gate2_LAT                  LATAbits.LATA1
#define Gate2_PORT                 PORTAbits.RA1
#define Gate2_ANS                  ANSELbits.ANS1
#define Gate2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define Gate2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define Gate2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define Gate2_GetValue()           PORTAbits.RA1
#define Gate2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define Gate2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define Gate2_SetAnalogMode()      do { ANSELbits.ANS1 = 1; } while(0)
#define Gate2_SetDigitalMode()     do { ANSELbits.ANS1 = 0; } while(0)

// get/set RB0 procedures
#define RB0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define RB0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define RB0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define RB0_GetValue()              PORTBbits.RB0
#define RB0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define RB0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define RB0_SetPullup()             do { WPUBbits.WPUB0 = 1; } while(0)
#define RB0_ResetPullup()           do { WPUBbits.WPUB0 = 0; } while(0)
#define RB0_SetAnalogMode()         do { ANSELHbits.ANS12 = 1; } while(0)
#define RB0_SetDigitalMode()        do { ANSELHbits.ANS12 = 0; } while(0)

// get/set RB1 procedures
#define RB1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define RB1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define RB1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define RB1_GetValue()              PORTBbits.RB1
#define RB1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define RB1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define RB1_SetPullup()             do { WPUBbits.WPUB1 = 1; } while(0)
#define RB1_ResetPullup()           do { WPUBbits.WPUB1 = 0; } while(0)
#define RB1_SetAnalogMode()         do { ANSELHbits.ANS10 = 1; } while(0)
#define RB1_SetDigitalMode()        do { ANSELHbits.ANS10 = 0; } while(0)

// get/set RB2 procedures
#define RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define RB2_GetValue()              PORTBbits.RB2
#define RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define RB2_SetPullup()             do { WPUBbits.WPUB2 = 1; } while(0)
#define RB2_ResetPullup()           do { WPUBbits.WPUB2 = 0; } while(0)
#define RB2_SetAnalogMode()         do { ANSELHbits.ANS8 = 1; } while(0)
#define RB2_SetDigitalMode()        do { ANSELHbits.ANS8 = 0; } while(0)

// get/set buzzer aliases
#define buzzer_TRIS                 TRISBbits.TRISB3
#define buzzer_LAT                  LATBbits.LATB3
#define buzzer_PORT                 PORTBbits.RB3
#define buzzer_WPU                  WPUBbits.WPUB3
#define buzzer_ANS                  ANSELHbits.ANS9
#define buzzer_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define buzzer_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define buzzer_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define buzzer_GetValue()           PORTBbits.RB3
#define buzzer_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define buzzer_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define buzzer_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define buzzer_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define buzzer_SetAnalogMode()      do { ANSELHbits.ANS9 = 1; } while(0)
#define buzzer_SetDigitalMode()     do { ANSELHbits.ANS9 = 0; } while(0)

// get/set MP1 aliases
#define MP1_TRIS                 TRISCbits.TRISC0
#define MP1_LAT                  LATCbits.LATC0
#define MP1_PORT                 PORTCbits.RC0
#define MP1_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define MP1_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define MP1_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define MP1_GetValue()           PORTCbits.RC0
#define MP1_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define MP1_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)

// get/set MP2 aliases
#define MP2_TRIS                 TRISCbits.TRISC1
#define MP2_LAT                  LATCbits.LATC1
#define MP2_PORT                 PORTCbits.RC1
#define MP2_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define MP2_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define MP2_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define MP2_GetValue()           PORTCbits.RC1
#define MP2_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define MP2_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)

// get/set RC2 procedures
#define RC2_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define RC2_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define RC2_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define RC2_GetValue()              PORTCbits.RC2
#define RC2_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define RC2_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)

// get/set RC3 procedures
#define RC3_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define RC3_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define RC3_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define RC3_GetValue()              PORTCbits.RC3
#define RC3_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define RC3_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)

// get/set RC4 procedures
#define RC4_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define RC4_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define RC4_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define RC4_GetValue()              PORTCbits.RC4
#define RC4_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define RC4_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/