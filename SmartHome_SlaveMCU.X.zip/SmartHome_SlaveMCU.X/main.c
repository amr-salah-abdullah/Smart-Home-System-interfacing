/* Slave main */

#include "mcc_generated_files/mcc.h"

uint8_t temprec = 0;
volatile uint8_t Gateflag = 1;
uint16_t dutyCycle;

uint8_t  spamProt = 0;
// Interruption routine for the fan controller to read from the I2C bus network
void I2C_SlaveRead() {
    temprec = SSPBUF;
}

// Interruption routine for the the smart gate system
void INT0interrupt(void){
    if (spamProt == 0){
        // Start the spam blocking for the duration of this cycle
        spamProt = 1;
        Gateflag = DATAEE_ReadByte(0x00);
 
        // If the gate is open, close it.
        if (Gateflag == 0x01){  
            Gate1_SetHigh();
            Gate2_SetLow();
            
            __delay_ms(2000);
            
            Gate1_SetLow();
            // Gateflag = 0;
            DATAEE_WriteByte(0x00, 0x00);
        } 
        // If the gate is closed, open it.
        else {  
            Gate2_SetHigh();
            Gate1_SetLow();
            
            __delay_ms(2000);
            
            Gate2_SetLow();
            // Gateflag = 1;
            DATAEE_WriteByte(0x00,0x01);
        }  
    }
    else {
        // Turn off the motor   
        Gate1_SetLow();
        Gate2_SetLow();
        // Switch on the buzzer for 1 second
        buzzer_SetHigh();
        __delay_ms(1000);
        buzzer_SetLow();
    }     
}

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    // Enable high priority global interrupts
    INTERRUPT_GlobalInterruptHighEnable();
    // Enable low priority global interrupts.
    INTERRUPT_GlobalInterruptLowEnable();   
    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
    
    //initialize the interruption routines
    INT0_SetInterruptHandler(INT0interrupt);
    //start the I2c connection as a slave MCU
    I2C_Open();
    I2C_SlaveSetReadIntHandler(I2C_SlaveRead);
    //main porgram loop
    while (1)
    {
        // spam protection reset for the gate
        spamProt = 0;
        //if the heat level received is higher than 35 degrees, turn on the fans
        if ((temprec >= 35) && (temprec < 40)){
            MP1_SetHigh();
            MP2_SetLow();
            // set duty cycle variable to 50%
            dutyCycle = 505; 
        }
        else if ((temprec >= 40) && (temprec < 50)){
            MP1_SetHigh();
            MP2_SetLow();
            // set duty cycle variable to 70%
            dutyCycle = 758;
        }
        // the 1 degree is to filter the reading noise on the I2C bus
        else if ((temprec <= 30) &&(temprec > 5)){
            MP1_SetLow();
            // set duty cycle variable to 0%
            dutyCycle = 0;
        }
        else{
        
            // do nothing
        }
        //apply the duty cycle based on the last given state
        EPWM1_LoadDutyValue(dutyCycle);
    }
}
 