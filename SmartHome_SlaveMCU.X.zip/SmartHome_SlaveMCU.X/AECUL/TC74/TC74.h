/* 
 * File:   TC74.h
 * Author: AMR SAAH ADULLAH
 *
 * Created on December 8, 2023, 2:47 PM
 */

#ifndef TC74_H
#define	TC74_H

#include "../../mcc_generated_files/mcc.h"
#include "../../mcc_generated_files/examples/i2c_master_example.h"

uint8_t ReadTemp(i2c_address_t addr);


#endif	/* TC74_H */

